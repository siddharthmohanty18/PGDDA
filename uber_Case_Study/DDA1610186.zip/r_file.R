#################### Case Study 1: Case Study- Uber Supply- Demand Gap ####################
#
# Name : Siddharth Mohanty
# Roll Number : DDA1610186
#
# Load the uber request data into data frame uber_data
#
uber_data <- read.csv("Uber request data.csv", header=T, stringsAsFactors = F)
#
#
################# Checkpoint 1: DATA PREPARATION ##################
#
# 
# Extracting the hour part from the Request.Time field
#
Hour.Booking <- substring(uber_data$Request.time, 1, 2)
#
# Adding the extracted hour column to the uber_data
#
uber_data_hour <- cbind(uber_data, Hour.Booking)
#
# Loading the ggplot and scales lib
#
library(ggplot2)
#
library(scales)
#
# 1 .Make a grouped bar chart depicting the hour-wise trip request made at city and 
# airport respectively. You can aggregate the data for all 5 days on the same axis 
# of 24 hours. Each bar should correspond to an hour and pick-up point (city / 
# airport) should be displayed in two colours
#
ggplot(uber_data_hour, aes(Hour.Booking, fill=Pickup.point)) + geom_bar(position="dodge")
#
# Add a blank column Time_Slot to the data frame uber_data_hour
#
Time.Slot <- vector(mode="character", length = nrow(uber_data_hour))
#
uber_time_slot <- cbind(uber_data_hour, Time.Slot)
#
# Convert the Time.Slot column in data frame uber_time_slot from factor to character
#
uber_time_slot$Time.Slot <- as.character(uber_time_slot$Time.Slot)
#
# Setting Time_Slot as Morning_Rush for 5,6,7,8 and 9 hours
#
uber_time_slot$Time.Slot[which(uber_time_slot$Hour.Booking == "05" | uber_time_slot$Hour.Booking == "06" | uber_time_slot$Hour.Booking == "07" | uber_time_slot$Hour.Booking == "08" | uber_time_slot$Hour.Booking == "09")] <- "Morning_Rush"
#
# Setting Time_Slot as Day_Time for 10,11,12,13,14 and 15 hours
#
uber_time_slot$Time.Slot[which(uber_time_slot$Hour.Booking == "10" | uber_time_slot$Hour.Booking == "11" | uber_time_slot$Hour.Booking == "12" | uber_time_slot$Hour.Booking == "13" | uber_time_slot$Hour.Booking == "14" | uber_time_slot$Hour.Booking == "15")] <- "Day_Time"
#
# Setting Time_Slot as Evening_Rush for 16,17,18,19,20 and 21 hours
#
uber_time_slot$Time.Slot[which(uber_time_slot$Hour.Booking == "16" | uber_time_slot$Hour.Booking == "17" | uber_time_slot$Hour.Booking == "18" | uber_time_slot$Hour.Booking == "19" | uber_time_slot$Hour.Booking == "20" | uber_time_slot$Hour.Booking == "21")] <- "Evening_Rush"
#
# Setting Time_Slot as Late_Night for 22,23,00 and 01 
#
uber_time_slot$Time.Slot[which(uber_time_slot$Hour.Booking == "22" | uber_time_slot$Hour.Booking == "23" | uber_time_slot$Hour.Booking == "00" | uber_time_slot$Hour.Booking == "01")] <- "Late_Night"
#
# Setting Time_Slot as Pre_Morning for 02,03 & 04 
#
uber_time_slot$Time.Slot[which(uber_time_slot$Hour.Booking == "02" | uber_time_slot$Hour.Booking == "03" | uber_time_slot$Hour.Booking == "04")] <- "Pre_Morning"
#
# Subsetting all the trips completed records out of uber_time_slot
#
uber_trip_completed <- subset(uber_time_slot, uber_time_slot$Status == "Trip Completed")
#
# Plot a bar chart for number of trips made during different time-slots 
#
ggplot(uber_trip_completed, aes(Time.Slot)) + geom_bar() + geom_text(aes(label = ..count..), stat= "count", vjust = -.5)
#
# Trips made during Pre_Morning
#
nrow(subset(uber_trip_completed, uber_trip_completed$Time.Slot == "Pre_Morning"))
#
# Trips made during Morning_Rush
#
nrow(subset(uber_trip_completed, uber_trip_completed$Time.Slot == "Morning_Rush"))
#
# Trips made during Day_Time
#
nrow(subset(uber_trip_completed, uber_trip_completed$Time.Slot == "Day_Time"))
#
# Trips made during Evening_Rush
#
nrow(subset(uber_trip_completed, uber_trip_completed$Time.Slot == "Evening_Rush"))
#
# Trips made during Late_Night
#
nrow(subset(uber_trip_completed, uber_trip_completed$Time.Slot == "Late_Night"))
#
#
################# Problem Identification ##################
#
################# Problem 1 ##################
#
# A stacked bar chart where each bar represents a time slot and the y-axis shows 
# the frequency of requests. Different proportions of bars should represent the 
# completed, cancelled and no cars available out of the total customer requests
#
ggplot(uber_time_slot, aes(Time.Slot, fill=factor(Status))) + geom_bar()
#
# Fetch all records for time slot Morning_Rush and status as Cancelled 
#
uber_time_slot_morning_rush_ncars <- subset(uber_time_slot, uber_time_slot$Time.Slot == "Morning_Rush" & uber_time_slot$Status == "Cancelled")
#
# Plot showing proportions of requests raised at airport or city for morning rush
# and status as cancelled.
#
ggplot(uber_time_slot_morning_rush_ncars, aes(Pickup.point)) + geom_bar() + geom_text(aes(label = ..count..), stat= "count", vjust = -.5)
#
# No of times this issue exists in the time slot is
#
nrow(uber_time_slot_morning_rush_ncars)
# 
# Find the percentage breakup for the total number of issues in this 
# time slot based on the pick-up point.
#
ggplot(uber_time_slot_morning_rush_ncars, aes(x=Pickup.point)) + geom_bar(aes(y = (..count..)/sum(..count..))) + scale_y_continuous(labels = percent_format()) +  geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25)
#
# No of trip requests made in city in morning_rush.
#
nrow(subset(uber_time_slot, uber_time_slot$Pickup.point == "City" & uber_time_slot$Time.Slot == "Morning_Rush"))
#
# No of trips completed from city to airport in morning rush
#
nrow(subset(uber_time_slot, uber_time_slot$Pickup.point == "City" & uber_time_slot$Status == "Trip Completed" & uber_time_slot$Time.Slot == "Morning_Rush"))
#
#
################# Problem 2 ##################
#
#
# Fetch all records for time slot Evening_Rush and status as No cars Available
#
uber_time_slot_evening_rush_ncars <- subset(uber_time_slot, uber_time_slot$Time.Slot == "Evening_Rush" & uber_time_slot$Status == "No Cars Available")
#
# Plot showing proportions of requests raised at airport or city for evening rush
# and status as No cabs available.
#
ggplot(uber_time_slot_evening_rush_ncars, aes(Pickup.point)) + geom_bar() + geom_text(aes(label = ..count..), stat= "count", vjust = -.5)
#
# No of times this issue exists in the time slot is
#
nrow(uber_time_slot_evening_rush_ncars)
# 
# Find the percentage breakup for the total number of issues in this 
# time slot based on the pick-up point.
#
ggplot(uber_time_slot_evening_rush_ncars, aes(x=Pickup.point)) + geom_bar(aes(y = (..count..)/sum(..count..))) + scale_y_continuous(labels = percent_format()) +  geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25)
#
# No of trip requests made in airport in evening_rush.
#
nrow(subset(uber_time_slot, uber_time_slot$Pickup.point == "Airport" & uber_time_slot$Time.Slot == "Evening_Rush"))
#
# No of trips completed from airport to city in evening rush
#
nrow(subset(uber_time_slot, uber_time_slot$Pickup.point == "Airport" & uber_time_slot$Status == "Trip Completed" & uber_time_slot$Time.Slot == "Evening_Rush"))
#


