####################  Assignment- Linear Regression ####################
#
#
# Loading the required libraries
#
library(car)
library(MASS)
library(ggplot2)
library(moments)
library(reshape2)
#
# Import the dataset
#
carmileage <- read.csv(file = "carMPG.csv", stringsAsFactors = F)
#
#
####################  Checkpoint1:  Business Understanding and Data Understanding ####################
#
#
# Check for duplicates in carmileage data set
#
sum(duplicated(carmileage))
#
# As the result is 0 there are no duplicate rows in carmileage data set
#
# Check for missing values in the data set
#
sum(is.na(carmileage))
#
# As the result is 0 there are no missing values in the data set.
#
# On inspection we found out that there is a special symbol "?" in the Horsepower column
#
table(carmileage$Horsepower)
#
# Will be replacing the special charecter now
#
# Checking the skewness of this column without ? symbol
#
skewness(as.numeric(carmileage$Horsepower[which(carmileage$Horsepower != "?")]))
#
# The skewness value is 1.083161 which means the distribution is slightly positively skewed which is negligible.
#
# Kurtosis for this variable
#
kurtosis(as.numeric(carmileage$Horsepower[which(carmileage$Horsepower != "?")]))
#
# The kurtosis value is 3.672822 which means the distribution is almost normal.
#
# Hence we should replace the ? mark with the mean value
#
carmileage$Horsepower[which(carmileage$Horsepower == "?")] <- as.character(round(mean(as.numeric(carmileage$Horsepower[which(carmileage$Horsepower != "?")])),digits = 0))
#
# Let us check the levels after replacing the mean value in horse power
#
levels(as.factor(carmileage$Horsepower))
#
# Univariate analysis for MPG
#
# Summary for mpg
#
summary(carmileage$MPG)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for MPG
#
ggplot(carmileage,aes(x=MPG))+geom_histogram(binwidth = 10)
#
# Finding skewness of MPG
#
skewness(carmileage$MPG)
#
# As the skewness value is 0.4405072 it is slightly positively skewed.
#
# Finding the kurtosis of MPG
#
kurtosis(carmileage$MPG)
#
# Kurtosis value of 2.481665 means that the distribution is nearly normal.
#
# Lets find out the standard deviation of MPG
#
sd(carmileage$MPG)
#
# Lets check for outliers in the field MPG using boxplot and boxplot.stats
#
boxplot(carmileage$MPG)
#
boxplot.stats(carmileage$MPG)
#
# There are no outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(carmileage$MPG, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is no abrupt jump hence there are no outliers
#
# Univariate analysis of Cylinders  
#
# Lets find the count in each Cylinder categories
#
table(factor(carmileage$Cylinders))
#
# Lets plot a bar chart for the same
#
ggplot(carmileage,aes(x=factor(Cylinders))) + geom_bar()
#
# 4 Cylinder has most number of counts
#
# Univariate analysis of displacement
#
# Summary for displacement
#
summary(carmileage$Displacement)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Displacement
#
ggplot(carmileage,aes(x=Displacement))+geom_histogram(binwidth = 50)
#
# Finding skewness of Displacement
#
skewness(carmileage$Displacement)
#
# As the skewness value is 0.7169301 it is slightly positively skewed.
#
# Finding the kurtosis of Displacement
#
kurtosis(carmileage$Displacement)
#
# Kurtosis value of 2.247712 means that the distribution is nearly normal.
#
# Lets find out the standard deviation of Displacement
#
sd(carmileage$Displacement)
#
# Lets check for outliers in the field Displacement using boxplot and boxplot.stats
#
boxplot(carmileage$Displacement)
#
boxplot.stats(carmileage$Displacement)
#
# There are no outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(carmileage$Displacement, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is no abrupt jump hence there are no outliers
#
# Univariate analysis for Horsepower
#
# Summary for Horsepower
#
summary(carmileage$Horsepower)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Displacement
#
ggplot(carmileage,aes(x=Displacement))+geom_histogram(binwidth = 50)
#
# Finding skewness of Displacement
#
skewness(carmileage$Displacement)
#
# As the skewness value is 0.7169301 it is slightly positively skewed.
#
# Finding the kurtosis of Displacement
#
kurtosis(carmileage$Displacement)
#
# Kurtosis value of 2.247712 means that the distribution is nearly normal.
#
# Lets find out the standard deviation of Displacement
#
sd(carmileage$Displacement)
#
# Lets check for outliers in the field Displacement using boxplot and boxplot.stats
#
boxplot(carmileage$Displacement)
#
boxplot.stats(carmileage$Displacement)
#
# There are no outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(carmileage$Displacement, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is no abrupt jump hence there are no outliers
#
# Univariate analysis of Horsepower
#
# The Horsepower type is char, lets convert it to numeric first
#
carmileage$Horsepower <- as.numeric(carmileage$Horsepower)
#
# Summary for Horsepower
#
summary(carmileage$Horsepower)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Horsepower
#
ggplot(carmileage,aes(x=Horsepower))+geom_histogram(binwidth = 10)
#
# Finding skewness of Horsepower
#
skewness(carmileage$Horsepower)
#
# As the skewness value is 1.091972 it is slightly positively skewed.
#
# Finding the kurtosis of Horsepower
#
kurtosis(carmileage$Horsepower)
#
# Kurtosis value of 3.729832 means that the distribution is nearly normal.
#
# Lets find out the standard deviation of Horsepower
#
sd(carmileage$Horsepower)
#
# Lets check for outliers in the field Horsepower using boxplot and boxplot.stats
#
boxplot(carmileage$Horsepower)
#
boxplot.stats(carmileage$Horsepower)
#
# There are outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(carmileage$Horsepower, seq(0,1,0.01))
#
# From the percentile distribution there is a jump of 13 between 89 and 90 percentile but we cant consider almost 10% values as outliers. On checking further we found that the jump in between other percentiles is max 10. Hence, we did not perform any outlier treatment for this variable
#
# Univariate analysis of Weight
#
# Summary for Weight
#
summary(carmileage$Weight)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Weight
#
ggplot(carmileage,aes(x=Weight))+geom_histogram(binwidth = 200)
#
# Finding skewness of Weight
#
skewness(carmileage$Weight)
#
# As the skewness value is 0.5290589 it is slightly positively skewed.
#
# Finding the kurtosis of Weight
#
kurtosis(carmileage$Weight)
#
# Kurtosis value of 2.209267 means that the distribution is nearly normal.
#
# Lets find out the standard deviation of Weight
#
sd(carmileage$Weight)
#
# Lets check for outliers in the field Weight using boxplot and boxplot.stats
#
boxplot(carmileage$Weight)
#
boxplot.stats(carmileage$Weight)
#
# There are no outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(carmileage$Weight, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is no abrupt jump hence there are no outliers
#
# Univariate analysis of Acceleration
#
# Summary for Acceleration
#
summary(carmileage$Acceleration)
#
# From the summary it seems there are no outliers in the data 
#
# Histogram for Acceleration
#
ggplot(carmileage,aes(x=Acceleration))+geom_histogram(binwidth = 1)
#
# Finding skewness of Acceleration
#
skewness(carmileage$Acceleration)
#
# As the skewness value is 0.2777251 it is slightly positively skewed.
#
# Finding the kurtosis of Acceleration
#
kurtosis(carmileage$Acceleration)
#
# Kurtosis value of 3.399208 means that the distribution is nearly normal.
#
# Lets find out the standard deviation of Acceleration
#
sd(carmileage$Acceleration)
#
# Lets check for outliers in the field Acceleration using boxplot and boxplot.stats
#
boxplot(carmileage$Acceleration)
#
boxplot.stats(carmileage$Acceleration)
#
# There are outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(carmileage$Acceleration, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is no abrupt jump hence there are no outliers
#
# From the percentiles its clear that between all percentiles there is a jump of less than 1 but between 99 and 100 there is a diff of more than 1.
# Hence all the points above 99% i.e 22.239 are outliers and have to be replaced by 22.239
#
# Outlier treatment for Acceleration
#
carmileage$Acceleration[which(carmileage$Acceleration > 22.239)] <- 22.239
#
# Univariate analysis of Model year	  
#
# Lets find the count in each Model year categories
#
table(factor(carmileage$Model_year))
#
# Lets plot a bar chart for the same
#
ggplot(carmileage,aes(x=factor(Model_year))) + geom_bar()
#
# 2012 year has majority of launches
#
# Univariate analysis of Origin	  
#
# Lets find the count in each Origin categories
#
table(factor(carmileage$Origin))
#
# Lets plot a bar chart for the same
#
ggplot(carmileage,aes(x=factor(Origin))) + geom_bar()
#
# 1 Origin has majority of cars under it
#
# Multivariate Analysis of all the continous variables
#
# Finding correlations for all different pairs of continuous variables i.e Mpg, Displacement, Horsepower, Weight and Acceleration
#
# Creating a data frame with only columns Mpg, Displacement, Horsepower, Weight and Acceleration in it
#
cor_data_frame <- data.frame(carmileage$MPG,carmileage$Displacement, carmileage$Horsepower, carmileage$Weight, carmileage$Acceleration)
#
# Change column names
#
colnames(cor_data_frame) <- c("MPG","Displacement","Horsepower","Weight","Acceleration")
# 
cor(cor_data_frame)
#
# Looking at the values there is a correlation between the variables MPG and Displacement, MPG and Horsepower, MPG and Weight. Also there is a strong correlation between Displacement and Horsepower, Displacement and Weight
# Also, there is high correlation between Horsepower and weight
#
# Lets check graphically for MPG vs Displacement
#
ggplot(cor_data_frame, aes(MPG, Displacement)) + geom_point() 
#
# Lets check graphically for MPG vs Horsepower
#
ggplot(cor_data_frame, aes(MPG, Horsepower)) + geom_point() 
#
# Lets check graphically for MPG vs Weight
#
ggplot(cor_data_frame, aes(MPG, Weight)) + geom_point() 
#
# Lets check graphically for MPG vs Acceleration
#
ggplot(cor_data_frame, aes(MPG, Acceleration)) + geom_point() 
#
# Lets check graphically for Displacement vs Horsepower
#
ggplot(cor_data_frame, aes(Displacement, Horsepower)) + geom_point() 
#
# Lets check graphically for Displacement vs Weight
#
ggplot(cor_data_frame, aes(Displacement, Weight)) + geom_point() 
#
# Lets check graphically for Displacement vs Acceleration
#
ggplot(cor_data_frame, aes(Displacement, Acceleration)) + geom_point() 
#
# Lets check graphically for Horsepower vs Weight
#
ggplot(cor_data_frame, aes(Horsepower, Weight)) + geom_point() 
#
# Lets check graphically for Horsepower vs Acceleration
#
ggplot(cor_data_frame, aes(Horsepower, Acceleration)) + geom_point() 
#
# Lets check graphically for Weight vs Acceleration
#
ggplot(cor_data_frame, aes(Weight, Acceleration)) + geom_point() 
#
# As our target variable is MPG lets see how MPG varies w.r.t other continous variables across various categorical variables
#
# Distribution of MPG across categorical variables
#
ggplot(carmileage, aes(x = MPG,fill=factor(Cylinders))) + geom_histogram(binwidth = 5)
#
ggplot(carmileage, aes(x = MPG,fill=factor(Model_year))) + geom_histogram(binwidth = 5)
#
ggplot(carmileage, aes(x = MPG,fill=factor(Origin))) + geom_histogram(binwidth = 5)
#
#
####################  Checkpoint 2: Data Cleaning and Preparation ####################
#
# First stage: Variables Formatting  
#
# Here we will convert the multi-valued discrete attributes to factors
#
carmileage$Cylinders <- as.factor(carmileage$Cylinders)
#
carmileage$Model_year <- as.factor(carmileage$Model_year)
#
carmileage$Origin <- as.factor(carmileage$Origin)
#
# After doing EDA, we found out that for Cyclinders variable cylinder 3 and 5 is insignificant in terms of car numbers.
# So will merge cylinder 3 and 4 to 3_4 and 5,6 to 5_6
#
# Checking the levels in cylinder variables
#
levels(carmileage$Cylinders)
#
# Changing 3 and 4 cylinders to 3_4
#
levels(carmileage$Cylinders)[1:2]<-"3_4"
#
# Changing 5 and 6 cylinders to 5_6
#
levels(carmileage$Cylinders)[2:3]<-"5_6"
#
# Creating bins for Model_year
#
levels(carmileage$Model_year)[1:4]<-"2003_2006"
#
levels(carmileage$Model_year)[2:5]<-"2007_2010"
#
levels(carmileage$Model_year)[3:7]<-"2011_2015"
#
# Performing variable transformation now
#
# Extracting the Company_Name from the car_name column.
#
car_model <- sapply(strsplit(carmileage$Car_Name," ", fixed = T),"[",1)
#
# Adding car_model to the carmileage data set
#
carmileage <- cbind(carmileage,car_model)
#
# Converting the car_model variable to factor
#
carmileage$car_model <- as.factor(carmileage$car_model)
#
# Lets check the levels in the car_model field
#
levels(carmileage$car_model)
#
# Here the levels chevroelt, chevrolet and chevy refer to chevrolet only. Lets change the levels chevroelt and chevy
#
levels(carmileage$car_model)[7:9] <- "chevrolet"
#
# Lets check the levels of car_model field again
#
levels(carmileage$car_model)
#
# Here maxda and mazda refer to mazda only. Lets do this change
#
levels(carmileage$car_model)[15:16] <- "mazda"
#
# Lets check the levels of car_model field again
#
levels(carmileage$car_model)
#
# Here mercedes and mercedes-benz refer to mercedes only. Lets do this change
#
levels(carmileage$car_model)[16:17] <- "mercedes"
#
# Lets check the levels of car_model field again
#
levels(carmileage$car_model)
#
# Here vokswagen, volkswagen and vw refer to volkswagen. Lets do this change
#
levels(carmileage$car_model)[c(30,31,33)] <- "volkswagen"
#
# Lets check the levels of car_model field again
#
levels(carmileage$car_model)
#
# Here toyota and toyouta refer to toyota. Lets do this change
#
levels(carmileage$car_model)[27:28] <- "toyota"
#
# Lets check the levels of car_model field again
#
levels(carmileage$car_model)
#
# Lets check the structure of carmileage data frame once again
#
str(carmileage)
#
# Creating numeric variables for categorical variable Cylinders
#
cylinders_numeric <- model.matrix(~Cylinders -1 , data=carmileage)
#
# As there are 3 levels we need 2 variables two represent three levels. Lets remove the first column
#
cylinders_numeric <- cylinders_numeric[,-1]
#
# Creating numeric variables for categorical variable Model_year
#
Model_year_numeric <- model.matrix(~Model_year -1 , data=carmileage) 
#
# As there are 3 levels we need 2 variables two represent three levels. Lets remove the first column
#
Model_year_numeric <- Model_year_numeric[,-1]
#
# Creating numeric variables for categorical variable Origin
#
Origin_numeric <- model.matrix(~Origin -1 , data=carmileage) 
#
# As there are 3 levels we need 2 variables two represent three levels. Lets remove the first column
#
Origin_numeric <- Origin_numeric[,-1]
#
# Creating numeric variables for categorical variable car_model
#
car_model_numeric <- model.matrix(~car_model -1 , data=carmileage) 
#
# As there are 31 levels we need 30 variables two represent 31. Lets remove the first column
#
car_model_numeric <- car_model_numeric[,-1]
#
# Now lets create the final data set and name it as carmileage_1
#
# Remove all the categorical variables which are converted to numeric types
#
carmileage_1 <- carmileage[,c(-2,-7,-8,-9,-10)]
#
# Adding the data frames cylinders_numeric, Model_year_numeric, Origin_numeric and car_model_numeric to carmileage_1
#
carmileage_1 <- cbind(carmileage_1, cylinders_numeric, Model_year_numeric, Origin_numeric, car_model_numeric)
#
# Lets check the final structure of the prepared data
#
str(carmileage_1)
#
# We can see all the columns in the data frame are of numeric type
#
# Now we will divide the data set into train and test data set with ratio 70:30 and seed values as 100.
#
set.seed(100)
#
indices= sample(1:nrow(carmileage_1), 0.7*nrow(carmileage_1))
#
train=carmileage_1[indices,]
#
test = carmileage_1[-indices,]
#
####################  Checkpoint 3: Model Development ####################
#
# Develop the first model 
#
model_1 <-lm(MPG~.,data=train)
#
# Lets check the summary of the model 
#
summary(model_1)
#
# Apply the stepwise approach
#
step <- stepAIC(model_1, direction="both")
#
# Run the step object
#
step
#
# Create a new model model_2 using the formula from step variable
#
model_2 <- lm(formula = MPG ~ Horsepower + Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + car_modeldatsun + car_modeldodge + 
                car_modelplymouth + car_modelpontiac + car_modeltriumph + 
                car_modelvolkswagen + Origin2, data = train)
#
# Lets find the summary of the model_2
#
summary(model_2)
#
# Will use VIF function to find multi collinearity between independent variables of model_2 and eliminate variables using vif and p value
#
# Find vif scores of all variables in model_2
#
vif(model_2)
#
# As per vif scores Horsepower and Weight both have high vif scores greater than 2 but they are highly significant so cannot be removed.
#
# Lets check if these two variables has a correlation with each other
#
# During multi variate analysis of EDA we had found out that indeed horsepower and weight have very high correlation with correlation value as 0.8606759.
#
# Hence, will be removing Horsepower as it has least significance 
#
# Create new model model_3 removing variable Horsepower
#
model_3 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + car_modeldatsun + car_modeldodge + 
                car_modelplymouth + car_modelpontiac + car_modeltriumph + 
                car_modelvolkswagen + Origin2, data = train)
#
# Summary of model_3
#
summary(model_3)
#
# Lets check the vif score for model_3
#
vif(model_3)
#
# All the variables have a vif score less than 2. So now we will remove variables using p values.
#
# Creating model_4 removing car_modeltriumph as its most insignificant.
#
model_4 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + car_modeldatsun + car_modeldodge + 
                car_modelplymouth + car_modelpontiac + 
                car_modelvolkswagen + Origin2, data = train)
#
# Lets check the summary of model_4
#
summary(model_4)
#
# Creating model_5 removing the variable car_modeldatsun.
#
model_5 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + car_modeldodge + 
                car_modelplymouth + car_modelpontiac + 
                car_modelvolkswagen + Origin2, data = train)
#
# Check summary of model_5
#
summary(model_5)
#
# Creating model_6 by removing the variable car_modeldodge
#
model_6 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + 
                car_modelplymouth + car_modelpontiac + 
                car_modelvolkswagen + Origin2, data = train)
#
# Check summary of model_6
#
summary(model_6)
#
# Create model_7 by removing variable Origin2
#
model_7 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + 
                car_modelplymouth + car_modelpontiac + 
                car_modelvolkswagen , data = train)
#
# Check summary of model_7
#
summary(model_7)
#
# Create model_8 by removing variable car_modelpontiac
#
model_8 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + 
                car_modelplymouth + 
                car_modelvolkswagen , data = train)
#
# Check summary of model_8
#
summary(model_8)
#
# Create model_9 by removing variable car_modelplymouth
#
model_9 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                Model_year2011_2015 + Origin3 + 
                car_modelvolkswagen , data = train)
#
# Check summary of model_9
#
summary(model_9)
#
# Create model_10 removing Origin3 variable
#
model_10 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                 Model_year2011_2015 + 
                 car_modelvolkswagen , data = train)
#
# Check summary of model_10
#
summary(model_10)
#
# Create model_11 removing car_modelvolkswagen variable
#
model_11 <- lm(formula = MPG ~ Weight + Cylinders5_6 + Model_year2007_2010 + 
                 Model_year2011_2015 , data = train)
#
# Check summary of model_11
#
summary(model_11)
#
# Here all the variables are highly significant and cannot be removed based on p-value
#
# The final Adjusted R Square value is 0.826. Which is above 0.80. Hence, the model is meeting buisness requirements.
#
#
####################  Checkpoint 4: Model Evaluation and Testing ####################
#
#
# Test the model on test dataset
#
Predict_1 <- predict(model_11,test[,-c(1)])
#
# Add a new column "test_mpg" into the test dataset
#
test$test_mpg <- Predict_1
#
# Calculate the correlation between the actual and predicted mpg values
#
cor(test$MPG, test$test_mpg)
#
# calculate the test R2 
#
cor(test$MPG, test$test_mpg)^2
#
# Here the R Square value of Test data is 0.8334587
#
#
####################  Checkpoint 5: Model acceptance or Rejection ####################
#
#
# Here all the buisness goals are met
#
# The model does not have more than 5 variables.
#
# The model has a RSquare value of 0.826 which is greater than 0.80.
#
# When tested on the test data set the R Square value is 0.8334587 which is again greater than 80%.
