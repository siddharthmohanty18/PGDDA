# Loading the required packages

library(arules)
library(car)
library(caret)
library(caTools)
library(class)
library(dplyr)
library(e1071)
library(ggplot2)
library(Hmisc)
library(klaR)
library(lubridate)
library(MASS)
library(moments)
library(Rcpp)
library(ROCR)
library(stringr)
library(pROC)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We first define the Business Objective for the analysis.

# Business Objective : To understand the driving factorsbehind churn and to build a model which would predict future churn.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Checkpoint-1: Data Understanding and Preparation of Master File.

# We now load the datasets 

churn_data <- read.csv("churn_data.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)

customer_data <- read.csv("customer_data.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)

internet_data <- read.csv("internet_data.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We observe that the variable customerID is the common key for all the three datasets.

# We first normalize the customerID by converting it to upper case and removing the white spaces if any.

churn_data$customerID <- toupper(trimws(churn_data$customerID))

customer_data$customerID <- toupper(trimws(customer_data$customerID))

internet_data$customerID <- toupper(trimws(internet_data$customerID))

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# First we check whether all the three datasets contain the same customer ids.

length(which(churn_data$customerID %in% customer_data$customerID))

length(which(customer_data$customerID %in% internet_data$customerID))

length(which(internet_data$customerID %in% churn_data$customerID))

# We thus observe that all the above commands give the length as 7043.
# Hence all the datasets have the same customer ids.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Now we collate the the three datasets into one using the customerID column.

# We first merge the churn_data and customer_data using customerID.

churn <- merge(churn_data, customer_data, by = "customerID", all = FALSE )

# We now merge churn and internet_data using customerID.

churn <- merge(churn, internet_data, by = "customerID", all = FALSE)

# Thus we have the churn dataset collating all the three separate datasets.

# We now have a look at the churn dataset.

View(churn)

# We analyse the structure of the churn dataset.

str(churn)

# The churn dataset has 7043 observation with 21 variables.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Checkpoint -2: Exploratory Data Analysis

# We now perform the exploratory data analysis by plotting graphs between the target (Churn) and independent variables.

# We now explore the relationship between variables Churn and tenure.

plot_1 <- ggplot(churn, aes(x = tenure, fill = as.factor(Churn))) + geom_bar(position = "dodge") 

plot_1 + labs(title = "Distribution of Customer Churn based on Tenure of Service", x = "Tenure of service", y = "Count of Customers", fill = "Churn Status")

# We observe that the customers with lesser tenure of service with Firm X are more likely to churn as compared to those with longer tenure.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and PhoneService.

plot_2 <- ggplot(churn, aes(x = PhoneService, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_2 + labs (title = "Distribution of Customer Churn based on  Landline Phone Service", x = "Landline Service Availed (No/Yes)", y = "Count of Customers", fill = "Churn Status")

# We observe that ~ 25% of customers without and ~ 27% of customers with landline phone service have churned.
# Thus a customer availing the landline phone service does not make a significant effect on customer churn.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and Contract.

plot_3 <- ggplot(churn, aes(x = Contract, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_3 + labs(title = "Distribution of Customer Churn based on Type of Contract", x = "Type of Contract", y = "Count of Customers", fill = "Churn Status")

# We observe that the customer churn for Firm X is highest among customers with Month-to-month contract (~ 43%) and lowest among customers with Two year contract (~ 3%).
# Thus the customer churn reduces with the increase in the lenght of contract.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and PaperlessBilling.

plot_4 <- ggplot(churn, aes(x = PaperlessBilling, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_4 + labs(title = "Distribution of customer Churn based on Billing type", x = "Opted for Paperless Billing (No/Yes)", y = "Count of Customers", fill = "Churn Status")

# We observe that the customer churn is higher among the customers who have opted for paperless billing (~ 34%) as compared to who have not (~ 16%).

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and PaymentMethod.

plot_5 <- ggplot(churn, aes(x = PaymentMethod, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_5 + labs(title = "Distribution of Customer Churn based on Bill Payment Method", x = "Bill Payment Method", y = "Count of Customers", fill = "Churn Status")

# We observe that the customer churn is highest among the customers who have opted for electronic check as bill payment option (~45%).

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and MonthlyCharges

plot_6 <- ggplot(churn, aes(x = MonthlyCharges, fill = as.factor(Churn))) + geom_histogram(binwidth = 10, position = "dodge") 

plot_6 + labs(title = "Distribution of Customer Churn based on MonthlyCharges", x = "Monthly Charges", y = "Count of Customers", fill = "Churn Status")

# We observe that the customers with Monthly Charges above 65 are more likely to churn.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and TotalCharges

plot_7 <- ggplot(churn, aes(x = TotalCharges, fill = as.factor(Churn))) + geom_histogram(binwidth = 500, position = "dodge") 

plot_7 + labs(title = "Distribution of Customer Churn based on TotalCharges", x = "Total Charges", y = "Count of Customers", fill = "Churn Status")

# We observe that the customers with Total Charges in the range 0 - 2000  are more likely to churn.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and gender.

plot_8 <- ggplot(churn, aes(x = gender, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_8 + labs(title = "Distribution of Customer Churn based on Gender", x = "Gender", y = "Count of Customers", fill = "Churn Status")

# We observe that the churn among the Female customers of Firm X is 26% while that among the Male customers is ~ 27%.
# Thus the Gender of the customer has no significant effect on the customer churn.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and SeniorCitizen.

plot_9 <- ggplot(churn, aes(x = as.factor(SeniorCitizen), fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_9 + labs(title = "Distribution of Customer Churn based on Senior Citizen Status", x = "Senior Citizen Status (0 = No, 1 = Yes)", y = "Count of Customers", fill = "Churn Status")

# We observe that customer churn among the Senior Citizens is ~ 42% while that among the non - Senior Citizens is ~ 24%.
# Thus Senior Citizens are more likely to churn as compared to the non-Senior Citizens.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and Partner.

plot_10 <- ggplot(churn, aes(x = Partner, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_10 + labs(title = "Distribution of Customer Churn based on Marital Status", x = "Marital Status", y = "Count of Customers", fill = "Churn Status")

# We observe that customer churn among customers without partners (~ 33%) is higher than that among customers with partner(~ 20%).
# Thus single customers or customers without partner have a higher chance of churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and Dependents.

plot_11 <- ggplot(churn, aes(x = Dependents, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_11 + labs(title = "Distribution of Customer Churn based on Dependent Status", x = "Dependent Status", y = "Count of Customers", fill = "Churn Status")

# We observe that the customers with no dependents have higher churn (~ 31%) as compared to those with dependents (~ 15%).
# Thus customers without any dependents have a higher chance of churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and MultipleLines.

plot_12 <- ggplot(churn, aes(x = MultipleLines, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_12 + labs(title = "Distribution of Customer Churn based on Multiple Connectivity Lines", x = "Multiple Lines for Connectivity", y = "Count of Customers", fill = "Churn Status")

# We observe that the customer churn among customers with multiple lines of connectivity is ~ 29%, while among those with no phone service and no multiple line is ~ 25% each.
# Thus customers have multiple lines of internet connectivity as slightly more likely to churn.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and InternetService.

plot_13 <- ggplot(churn, aes(x = InternetService, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_13 + labs(title = "Distribution of Customer Churn based on Type of Internet Service", x = "Type of Ineternet Service", y = "Count of Customers", fill = "Churn Status")

# we observe that the customer churning is highest among customers using Fiber Optic based Internet Service (~ 42%), followed by DSL type (~ 19%) and No Ineternet Service (~ 7%).
# Thus customers using Fiber Optic Internet Service have high probability of churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and OnlineSecurity.

plot_14 <- ggplot(churn, aes(x = OnlineSecurity, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_14 + labs(title = "Distribution of Customer Churn based on Online Security Status", x = "Online Security Status (No/Yes)", y = "Count of Customers", fill = "Churn Status")

# We observe that customer with no Online Security have higher churn (~ 42%) as compared to those who have Online Security (~ 15%).
# Thus there is more likelihood of churning among customers not having Online Security.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and OnlineBackup.

plot_15 <- ggplot(churn, aes(x = OnlineBackup, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_15 + labs(title = "Distribution of Customer Churn based on Online Backup Status", x = "Online Backup Status", y = "Count of Customers", fill = "Churn Status")

# We observe that customers who have no Online Backup have higher churn (~ 40%) as compared to the customers who have Online Backup (~ 22%).
# Thus there is more possibility of churning among customers who do not have Online Backup.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and DeviceProtection.

plot_16 <- ggplot(churn, aes(x = DeviceProtection, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_16 + labs(title = "Distribution of Customer Churn based on Device Protection Status", x = "Device Protection Status", y = "Count of Customers", fill = "Churn Status")

# We observe that the customers who have not availed Device Protection have higher churn (~ 40%) than those who have availed Device Protection (~ 22%).
# Thus customers without Device Protection have a higher probability of churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and TechSupport.

plot_17 <- ggplot(churn, aes(x = TechSupport, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_17 + labs(title = "Distribution of Customer Churn based on Tech Support Status", x = "Tech Support Status", y = "Count of Customers", fill = "Churn Status")

# We observe that customers who have not opted for Tech Support have higher churn (~ 42%) as compared to those who have opted for Tech Support (~ 15%).
# Thus customers not opting for Tech Support have higher chances of churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and StreamingTV.

plot_18 <- ggplot(churn, aes(x = StreamingTV, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_18 + labs(title = "Distribution of Customer Churn based on TV Streaming Option", x = "TV Streaming Option", y = "Count of Customers", fill = "Churn Status")

# We observe that the customer who do not have the option of TV Streaming have a slightly higher churning (~ 34%) than those who have the TV Streaming option (~ 30%).
# Thus TV Streaming facility does not have a major influence on customer churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now explore the relationship between variables Churn and StreamingMovies.

plot_19 <- ggplot(churn, aes(x = StreamingMovies, fill = as.factor(Churn))) + geom_bar(position = "dodge") + geom_text(stat = "count", aes(label = ..count.., y = ..count..))

plot_19 + labs(title = "Distribution of Customer Churn based on Movie Streaming Option", x = "Movie Streaming Option", y = "Count of Customers", fill = "Churn Status")

# We observe that the customers not availing Movie Streaming option have a slightly higher churn (~ 34%) than those availing the Movie Streaming option (~ 30%).
# Thus Movie Streaming facility does not have a major influence on customer churning.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Checkpoint -3: Data Preparation

# In this step we clean the german_credit dataset of duplicate values, missing values and outliers.

#------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------

# Step 1 : Duplicate value treatment.

# checking for duplicate values in churn dataset.

nrow(unique(churn))

sum(duplicated(churn))

# We observe that the number of unique rows in the churn dataset is still 7043.
# Also there are 0 duplicate values in the dataset.
# Hence there are no duplicate values in the churn dataset.

#------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------

# Step 2 : Missing value treatment.

# Checking for missing values in churn dataset.

sum(is.na(churn))

# Thus we observe that there are 11 missing values in the churn dataset.

# Now we check the summary of the churn dataset.

summary(churn)

# Thus we observe that all the 11 missing values in churn dataset belong to variable TotalCharges.

# We replace the missing values by mean value of TotalCharges.

churn$TotalCharges[which(is.na(churn$TotalCharges) == TRUE)] <- mean(churn$TotalCharges, na.rm = TRUE)

# Rechecking the missing values in TotalCharges.

sum(is.na(churn$TotalCharges))

# Thus all the missing values in churn dataset have been treated.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Step 3 : Outlier treatment.

# We check for the outliers in the churn dataset and remove the same.

# We first check for outliers in variable tenure.

outlier_1 <- boxplot.stats(churn$tenure)$out

outlier_1

quantile(churn$tenure, seq(0,1,0.01))

# We observe no abnormal jump in values in tenure.
# Thus there are no outliers in tenure.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now check for outliers in variable MonthlyCharges.

outlier_2 <- boxplot.stats(churn$MonthlyCharges)$out

outlier_2

quantile(churn$MonthlyCharges, seq(0,1,0.01))

# We observe no abnormal jump in values in MonthlyCharges.
# Thus there are no outliers in MonthlyCharges.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now check for outliers in variable TotalCharges.

outlier_3 <- boxplot.stats(churn$TotalCharges)$out

outlier_3

quantile(churn$TotalCharges, seq(0,1,0.01))

# We observe no abnormal jump in values in TotalCharges.
# Thus there are no outliers in TotalCharges.

#------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------

# Step 4 : Variable formatting.

# Checking the structure of the churn dataset.

str(churn)

# We observe that there are a number of variables of 'character' type.
# We change the type of these variables from 'character' to 'factor'.

churn$PhoneService <- as.factor(churn$PhoneService)

churn$Contract <- as.factor(churn$Contract)

churn$PaperlessBilling <- as.factor(churn$PaperlessBilling)

churn$PaymentMethod <- as.factor(churn$PaymentMethod)

churn$Churn <- as.factor(churn$Churn)

churn$gender <- as.factor(churn$gender)

churn$Partner <- as.factor(churn$Partner)

churn$Dependents <- as.factor(churn$Dependents)

churn$MultipleLines <- as.factor(churn$MultipleLines)

churn$InternetService <- as.factor(churn$InternetService)

churn$OnlineSecurity <- as.factor(churn$OnlineSecurity)

churn$OnlineBackup <- as.factor(churn$OnlineBackup)

churn$DeviceProtection <- as.factor(churn$DeviceProtection)

churn$TechSupport <- as.factor(churn$TechSupport)

churn$StreamingTV <- as.factor(churn$StreamingTV)

churn$StreamingMovies <- as.factor(churn$StreamingMovies)

# Standardizing all the continous numeric variables

churn$tenure <- scale(churn$tenure)

churn$MonthlyCharges <- scale(churn$MonthlyCharges)

churn$TotalCharges <- scale(churn$TotalCharges)

# Rechecking the structure of churn dataset.

str(churn)

# Creating another data set churn_naive_bayes to be used with naive bayes algo

churn_naive_bayes <- churn

# Removing the customerid column as it is irrelevant

churn_naive_bayes <- churn_naive_bayes[,-1]

#------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------

# Step 5 : Variable transformation.

# Now we process the churn dataset for variable transformation by creating dummy variables.

# We now create dummy variables for Contract.

dummy_1 <- as.data.frame(model.matrix(~ Contract-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_1.

dummy_1 <- dummy_1[,-1]

# Now adding dummy_1 to churn and removing Contract.

churn <- cbind(churn[, -4], dummy_1)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for PaymentMethod.

dummy_2 <- as.data.frame(model.matrix(~ PaymentMethod-1, data = churn))

# For n (= 4) levels in a variable we need n-1 (= 3) dummy variables, hence removing the first column from dummy_2.

dummy_2 <- dummy_2[, -1]

# Now adding dummy_2 to churn and removing PaymentMethod.

churn <- cbind(churn[, -5], dummy_2)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variable for MultipleLines.

dummy_3 <- as.data.frame(model.matrix(~ MultipleLines-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_3.

dummy_3 <- dummy_3[, -1]

# Now adding dummy_3 to churn and removing MultipleLines.

churn <- cbind(churn[, -12], dummy_3)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for InternetService.

dummy_4 <- as.data.frame(model.matrix(~ InternetService-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_4.

dummy_4 <- dummy_4[, -1]

# Now adding dummy_4 to churn and removing InternetService.

churn <- cbind(churn[, -12], dummy_4)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for OnlineSecurity.

dummy_5 <- as.data.frame(model.matrix(~ OnlineSecurity-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_5.

dummy_5 <- dummy_5[, -1]

# Now adding dummy_5 to churn and removing OnlineSecurity.

churn <- cbind(churn[, -12], dummy_5) 

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for OnlineBackup.

dummy_6 <- as.data.frame(model.matrix(~ OnlineBackup-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_6.

dummy_6 <- dummy_6[, -1]

# Now adding dummy_6 to churn and removing OnlineBackup.

churn <- cbind(churn[, -12], dummy_6)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for DeviceProtection.

dummy_7 <- as.data.frame(model.matrix(~ DeviceProtection-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_7.

dummy_7 <- dummy_7[, -1]

# Now adding dummy_7 to churn and removing DeviceProtection.

churn <- cbind(churn[, -12], dummy_7)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for TechSupport.

dummy_8 <- as.data.frame(model.matrix(~ TechSupport-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_8.

dummy_8 <- dummy_8[, -1]

# Now adding dummy_8 to churn and removing TechSupport.

churn <- cbind(churn[, -12], dummy_8)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for StreamingTV.

dummy_9 <- as.data.frame(model.matrix(~ StreamingTV-1, data = churn))

# For n (=3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column from dummy_9.

dummy_9 <- dummy_9[, -1]

# Now adding dummy_9 to churn and removing Streaming.

churn <- cbind(churn[, -12], dummy_9)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now create dummy variables for StreamingMovies.

dummy_10 <- as.data.frame(model.matrix(~ StreamingMovies-1, data = churn))

# For n (= 3) levels in a variable we need n-1 (= 2) dummy variables, hence removing the first column form dummy_10.

dummy_10 <- dummy_10[, -1]

# Now adding dummy_10 to churn and removing StreamingMovies.

churn <- cbind(churn[, -12], dummy_10)

# Storing the churn data set into a data set churn_logistic and this will be used further in logistic regression

churn_logistic <- churn

churn_logistic$Churn <- ifelse(churn_logistic$Churn == "No", 0, 1)


#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# For logistic regression in the data set churn_logistic We need not create dummy variable for PhoneService, PaperlessBilling, Churn, gender, Partner & Dependents as they have only two levels.

# Also since customerID is not of any relevance in the analysis, we can remove the same from our dataset.

churn_logistic <- churn_logistic[, -1]

# Lets create dummy variables for PhoneService, PaperlessBilling, gender, Partner & Dependents in the churn data frame 

# Creating dummy variables for PhoneService

dummy_11 <- as.data.frame(model.matrix(~ PhoneService-1, data = churn))

# For n (= 2) levels in a variable we need n-1 (= 1) dummy variables, hence removing the first column form dummy_11.

PhoneServiceYes <- dummy_11[2]

# Now adding dummy_11 to churn and removing PhoneService

churn <- cbind(churn[, -3], PhoneServiceYes)

# Creating dummy variables for PaperlessBilling

dummy_12 <- as.data.frame(model.matrix(~ PaperlessBilling-1, data = churn))

# For n (= 2) levels in a variable we need n-1 (= 1) dummy variables, hence removing the first column form dummy_12.

dummy_12 <- dummy_12[-1]

# Now adding dummy_12 to churn and removing PaperlessBilling

churn <- cbind(churn[,-3], dummy_12)

# Creating dummy variables for gender

dummy_13 <- as.data.frame(model.matrix(~ gender-1, data = churn))

# For n (= 2) levels in a variable we need n-1 (= 1) dummy variables, hence removing the first column form dummy_13.

dummy_13 <- dummy_13[-1]

# Now adding dummy_13 to churn and removing gender

churn <- cbind(churn[,-6], dummy_13)

# Creating dummy variables for Partner

dummy_14 <- as.data.frame(model.matrix(~ Partner-1, data = churn))

# For n (= 2) levels in a variable we need n-1 (= 1) dummy variables, hence removing the first column form dummy_14.

dummy_14 <- dummy_14[-1]

# Now adding dummy_14 to churn and removing Partner

churn <- cbind(churn[,-7], dummy_14)

# Creating dummy variables for Dependents

dummy_15 <- as.data.frame(model.matrix(~ Dependents-1, data = churn))

# For n (= 2) levels in a variable we need n-1 (= 1) dummy variables, hence removing the first column form dummy_15.

dummy_15 <- dummy_15[-1]

# Now adding dummy_15 to churn and removing Dependents

churn <- cbind(churn[,-7], dummy_15)

# Now as the customer ID is not relevant will remove that field from the churn data set

churn <- churn[,-1]

# Lets change the variables 

# Assigning the data set 

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Checking the structure of the dataset churn which will be used for KNN and SVM.

str(churn)

# It has Churn as categorical type and rest as numeric type ideal for KNN and SVM

# Checking the structure of the dataset churn_logistic which will be used for logistic regression

str(churn_logistic)

# Checking the structure of the dataet churn_naive_bayes which will be used for naive bayes

str(churn_naive_bayes)

# Hence the datasets has been prepared for model development.

#------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------

# Step 6 : Model Development.

# Splitting the data into train and test for KNN and SVM

set.seed(100)

train_indices_churn <- sample.split(churn$Churn, SplitRatio = 0.7)

train=churn[train_indices_churn == TRUE,]

test=churn[train_indices_churn == FALSE,]

# Using the train() command to find the best K.

model <- train(
  Churn~., 
  data=train,
  method='knn',
  tuneGrid=expand.grid(.k=1:50),
  metric='Accuracy',
  trControl=trainControl(
    method='repeatedcv', 
    number=5, 
    repeats=15))

# Using Cross-Validated (10 fold, repeated 15 times) we found out that optimal k is 31

# Generating the plot of the model

plot(model)

# Lets build the knn model with k = 31

# Train and test data without the true levels

c1 <- train[,4]

train_no_level <- train[,-4] 

test_no_level <- test[,-4]

# Generating levels for the test data using the knn function. Here k value is 31

impknn31 <- knn(train_no_level,test_no_level, c1, k = 31,
                prob = TRUE)

# Lets check the performance of the model.

table(impknn31,test[,4])

confusionMatrix(impknn31, test[,4], positive ="Yes" )

# Thus we observe the following :

# Accuracy    : 0.79
# Sensitivity : 0.52
# Specificity : 0.88

# ROC with probablities for KNN

predprob_knn <- attr(impknn31, "prob")

realvec_knn <- ifelse(impknn31=="Yes",0,1)

pr_knn <- prediction(predprob_knn,realvec_knn)

prf_knn <- performance(pr_knn,"tpr","fpr")

plot(prf_knn)

auc(realvec_knn,predprob_knn)

# Area under the curve: 0.7936

#------------------------------------------------------------------------------------------------------

# Lets build the naive bayes model

train_naive_bayes <- churn_naive_bayes[train_indices_churn == TRUE,]

test_naive_bayes <- churn_naive_bayes[train_indices_churn == TRUE,]

# Creating the test data without actual labels

test_naive_bayes_1 <- test_naive_bayes[,-4]

# Now we will run Naive Bayes algorithm on this data

model_naive_bayes <- naiveBayes(Churn ~. , data = train_naive_bayes)

# Predict the class labels for the test data

pred_naive_bayes <- predict(model_naive_bayes, test_naive_bayes_1)

# Lets check the performance of this naive bayes model using table and confusionMatrix functions

table(pred_naive_bayes, test_naive_bayes$Churn)

confusionMatrix(pred_naive_bayes, test_naive_bayes$Churn, positive = "Yes")

# Thus we observe the following :

# Accuracy    : 0.7284
# Sensitivity : 0.7982
# Specificity : 0.7032

# ROC with probablities for Naive Bayes

predraw_naive_bayes <- predict(model_naive_bayes, test_naive_bayes_1, type="raw")

predprob_naive_bayes <- predraw_naive_bayes[,1]

realvec_naive_bayes <- ifelse(test_naive_bayes$Churn=="Yes",0,1)

pr_naive_bayes <- prediction(predprob_naive_bayes,realvec_naive_bayes)

prf_naive_bayes <- performance(pr_naive_bayes,"tpr","fpr")

plot(prf_naive_bayes)

auc(realvec_naive_bayes,predprob_naive_bayes)

# Area under the curve: 0.8176

#------------------------------------------------------------------------------------------------------

# Lets build a SVM model

# Using tune command to find the optimal model

tune.churn.svm = tune(svm, Churn ~., data = train, kernel = "linear", ranges = list(cost = c(0.001, 0.01, 0.1, 0.5, 1, 10, 100)))
summary(tune.churn.svm)

# the tune function also stores the best model obtained
# cost = 0.5 is the best model

best.mod = tune.churn.svm$best.model

best.mod

# predicting test classes using the best model and analyzing the table
# best.model is the one with cost = 0.5

pred_svm = predict(best.mod, test)

table(predicted = pred_svm, truth = test$Churn)

confusionMatrix(pred_svm, test$Churn, positive = "Yes")

# Thus we observe the following :

# Accuracy    : 0.79
# Sensitivity : 0.52
# Specificity : 0.90

# ROC with probablities for SVM

predraw_SVM <- predict(best.mod, test, decision.values=TRUE)

predprob_SVM <- attr(predraw_SVM,"decision.values")

realvec_SVM <- ifelse(test$Churn=="Yes",0,1)

pr_SVM <- prediction(predprob_SVM,realvec_SVM)

prf_SVM <- performance(pr_SVM,"tpr","fpr")

plot(prf_SVM)

auc(realvec_SVM,predprob_SVM)

# Area under the curve: 0.83

#------------------------------------------------------------------------------------------------------

# Model development for logistic regression

indices_log <- sample.split(churn_logistic[,10], SplitRatio = 0.7)

train_glm <- churn_logistic[indices_log == TRUE,]
test_glm <- churn_logistic[indices_log == FALSE,]

# Checkpoint 4: Model Building

# 3.	Model -Logistic Regression: 

# Step 1 : Model Development.

# For the logistic regression model we take the vif threshold to be 2.

# We now develop our first model (glm_model_1) using the train_glm dataset.

glm_model_1 <- glm(Churn ~ ., family = "binomial", data = train_glm)

# Checking the summary of glm_model_1.

summary(glm_model_1)

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now apply the step wise selection to remove the insignificant variables.

step <- stepAIC(glm_model_1, direction = "both")

# Running the step object.

step

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_2 after the step wise selection, using the formula as provided in the step object.

glm_model_2 <- glm(formula = Churn ~ tenure + PaperlessBilling + MonthlyCharges + 
                     TotalCharges + SeniorCitizen + Dependents + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` + MultipleLinesYes + 
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes + StreamingMoviesYes, family = "binomial", 
                   data = train_glm)


# Checking the summary of glm_model_2.

summary(glm_model_2)

# Calculating the VIF for glm_model_2.

vif(glm_model_2)

# We observe that all variables having VIF > 2 have also high level of significance.

# We also observe that MonthlyCharges and TotalCharges both have very high VIF values, hence they might be correalted.

# Checking the correlation between MontlyCharges and TotalCharges.

cor(train_glm$MonthlyCharges, train_glm$TotalCharges)

# Thus we observe that MontlyCharges and TotalCharges are higly correlated (~65%).
# Hence we remove the variable MonthlyCharges from glm_model_2 since it has lower significance out of the two.

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_3 removing MonthlyCharges.

glm_model_3 <- glm(formula = Churn ~ tenure + PaperlessBilling +  
                     TotalCharges + SeniorCitizen + Dependents + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` + MultipleLinesYes + 
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes + StreamingMoviesYes, family = "binomial", 
                   data = train_glm)


# Checking the summary of glm_model_3.

summary(glm_model_3)

# Calculating the VIF for glm_model_3.

vif(glm_model_3)

# We observe that the variable TotalCharges has the highest VIF value and it also has low significance.

# Hence we remove the variable TotalCharges from glm_model_3.

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_4 removing TotalCharges.

glm_model_4 <- glm(formula = Churn ~ tenure + PaperlessBilling + SeniorCitizen + Dependents + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` + MultipleLinesYes + 
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes + StreamingMoviesYes, family = "binomial", 
                   data = train_glm)


# Checking the summary of glm_model_4.

summary(glm_model_4)

# Calculating the VIF for glm_model_4.

vif(glm_model_4)

# We observe that all the variables have VIF values < 2. Hence now we remove the insignificant variables through p-value.

# We thus remove the variable SeniorCitizen from glm_model_4 since it has the highest p-value.

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_5 removing SeniorCitizen.

glm_model_5 <- glm(formula = Churn ~ tenure + PaperlessBilling + Dependents + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` + MultipleLinesYes + 
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes + StreamingMoviesYes, family = "binomial", 
                   data = train_glm)


# Checking the summary of glm_model_5.

summary(glm_model_5)

# We remove the variable MultipleLinesYes from glm_model_5 since it has the highest p-value.

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_6 removing MultipleLinesYes.

glm_model_6 <- glm(formula = Churn ~ tenure + PaperlessBilling + Dependents + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` +  
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes + StreamingMoviesYes, family = "binomial", 
                   data = train_glm)


# Checking the summary of glm_model_6.

summary(glm_model_6)

# We remove the variable DependentsYes from glm_model_6 since it has the highest p-value.

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_7 removing DependentsYes.

glm_model_7 <- glm(formula = Churn ~ tenure + PaperlessBilling + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` +  
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes + StreamingMoviesYes, family = "binomial", 
                   data = train_glm)


# Checking the summary of glm_model_7.

summary(glm_model_7)

# We remove the variable StreamingMoviesYes from glm_model_7 since it has the highest p-value.

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now develop glm_model_8 removing StreamingMoviesYes.

glm_model_8 <- glm(formula = Churn ~ tenure + PaperlessBilling + `ContractOne year` + 
                     `ContractTwo year` + `PaymentMethodElectronic check` +  
                     `InternetServiceFiber optic` + InternetServiceNo + OnlineSecurityYes + 
                     TechSupportYes + StreamingTVYes, family = "binomial", data = train_glm)


# Checking the summary of glm_model_8.

summary(glm_model_8)

# We observe that all the variables in glm_model_8 have high level of significance.

# Hence glm_model_8 is the final model for our analysis.

final_model <- glm_model_8

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Step 2 : Model Evaluation

# C-Statistic

# We first calculate the C-statistic for train data

train_glm$predicted_prob <- predict(final_model, newdata = train_glm, type = "response")

rcorr.cens(train_glm$predicted_prob, train_glm$Churn)

# We observe that the value of C-statistic for train data is 0.85, which is acceptable.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now calculate the C-statistic for test data

test_glm$predicted_prob <- predict(final_model, newdata = test_glm, type = "response")

rcorr.cens(test_glm$predicted_prob, test_glm$Churn)

# We observe that the value of C-statistic for test data is 0.83, which is also acceptable.

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# KS-Statistic

# We first calculate KS-statistic for train data

model_score_train <- prediction(train_glm$predicted_prob, train_glm$Churn)

model_performance_train <- performance(model_score_train, "tpr", "fpr")

ks_table_train <- attr(model_performance_train, "y.values")[[1]] - (attr(model_performance_train, "x.values")[[1]])

ks_train <- max(ks_table_train)

ks_train

# Thus the KS-statistic for train data is 0.54

# We find the decile in which the KS-statistic lies

decile_train <- (which(ks_table_train == ks_train)) / (nrow(train_glm))

decile_train

# Thus we observe that the KS-statistic for train data lies in the second decile, which is acceptable.

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We now calculate the KS-statistic for test data

model_score_test <- prediction(test_glm$predicted_prob, test_glm$Churn)

model_performance_test <- performance(model_score_test, "tpr", "fpr")

ks_table_test <- attr(model_performance_test, "y.values")[[1]] - (attr(model_performance_test, "x.values")[[1]])

ks_test <- max(ks_table_test) 

ks_test

# Thus the KS-statistic for test data is 0.52

# We now find the decile in which the KS-statistic lies

decile_test <- (which(ks_table_test == ks_test)) / (nrow(test_glm))

decile_test

# Thus we observe that the KS-statistic for the test data lies in the third decile, which is acceptable.

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Step 3 : Threshold value

# We now plot the ROc curve for train data for selecting the threshold value

plot(model_performance_train, colorize = TRUE, lwd = 2, lab = c(10,10,10))

lines(x=c(0, 1), y=c(0, 1), col="black", lty=2)

# Lets find the area under the curve

auc(test_glm$Churn, test_glm$predicted_prob)

# Area under the curve: 0.8345

# Thus the plot shows that the final_model is able to have a reasonable separation.

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# We check for the Accuracy, Sensitivity and Specificity for final_model.

# Checking the Accuracy, Sensitivity and Specificity of final_model on train data keeping threshold as 0.3,0.5 & 0.7.

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# For threshold = 0.3, for train_glm.

confusionMatrix(as.numeric(train_glm$predicted_prob > 0.3), train_glm$Churn, positive = "1")

# Thus we observe the follwoing :

# Accuracy    : 0.76
# Sensitivity : 0.75
# Specificity : 0.76

# For threshold = 0.3, for test_glm.

confusionMatrix(as.numeric(test_glm$predicted_prob > 0.3), test_glm$Churn, positive = "1")

# Thus we observe the follwoing :

# Accuracy    : 0.78
# Sensitivity : 0.80
# Specificity : 0.77

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# For threshold = 0.5, for train_glm.

confusionMatrix(as.numeric(train_glm$predicted_prob > 0.5), train_glm$Churn, positive = "1")

# Thus we observe the follwoing :

# Accuracy    : 0.79
# Sensitivity : 0.51
# Specificity : 0.89

# For threshold = 0.5, for test_glm.

confusionMatrix(as.numeric(test_glm$predicted_prob > 0.5), test_glm$Churn, positive = "1")

# Thus we observe the follwoing :

# Accuracy    : 0.81
# Sensitivity : 0.57
# Specificity : 0.90

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# For threshold = 0.7, for train_glm.

confusionMatrix(as.numeric(train_glm$predicted_prob > 0.7), train_glm$Churn, positive = "1")

# Thus we observe the follwoing :

# Accuracy    : 0.77
# Sensitivity : 0.18
# Specificity : 0.98

# For threshold = 0.7, for test_glm.

confusionMatrix(as.numeric(test_glm$predicted_prob > 0.7), test_glm$Churn, positive = "1")

# Thus we observe the follwoing :

# Accuracy    : 0.77
# Sensitivity : 0.21
# Specificity : 0.98

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Thus threshold = 0.3 gives the optimum results for the model.

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
