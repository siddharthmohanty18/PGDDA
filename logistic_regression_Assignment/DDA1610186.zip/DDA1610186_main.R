# Loading the required libraries
#
library(car)
library(Hmisc)
library(ROCR)
library(caret)
library(MASS)
library(ggplot2)
library(moments)
library(reshape2)
library(caTools)
#
# Download the data set as german_credit
#
german_credit <- read.csv(file="german.csv", stringsAsFactors = F)
#
# Check the structure of the data frame german_credit
#
str(german_credit)
#
# There are 21 columns out of which 8 are numerical and rest are categorical.
#
# Data prpeapartion and feature transformation
#
# Lets check for NA values
#
sum(is.na(german_credit))
#
# As the result is 0 we dont have any NA values
#
# Check for duplicates in german_credit data set
#
sum(duplicated(german_credit))
#
# As the result is 0 there are no duplicate rows in german_credit data set
#
# Let's go for univariate analysis of all numeric continous variables
#
# Univariate analysis of Duration.in.month
#
# Summary for Duration.in.month
#
summary(german_credit$Duration.in.month)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Duration.in.month
#
ggplot(german_credit,aes(x=Duration.in.month))+geom_histogram(binwidth = 5)
#
# Finding skewness of Duration.in.month
#
skewness(german_credit$Duration.in.month)
#
# As the skewness value is 1.092542 it is positively skewed.
#
# Finding the kurtosis of Duration.in.month
#
kurtosis(german_credit$Duration.in.month)
#
# Kurtosis value of 3.909195 means that the distribution is not normal.
#
# Lets find out the standard deviation of Duration.in.month
#
sd(german_credit$Duration.in.month)
#
# Lets check for outliers in the field Duration.in.month using boxplot and boxplot.stats
#
boxplot(german_credit$Duration.in.month)
#
boxplot.stats(german_credit$Duration.in.month)
#
# There are lot of outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(german_credit$Duration.in.month, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is abrupt jump between 93% and 94%. So we will have to replace the values greater than 42.21 as 42.21
#
# Outlier treatment for Duration.in.month
#
german_credit$Duration.in.month[which(german_credit$Duration.in.month > 42.21)] <- 42.21
#
# Lets plot the box plot again for Duration.in.month
#
boxplot(german_credit$Duration.in.month)
#
boxplot.stats(german_credit$Duration.in.month)
#
# Its clear that the outliers have reduced.
#
# Univariate analysis of Credit.amount
#
# Summary for Credit.amount
#
summary(german_credit$Credit.amount)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Credit.amount
#
ggplot(german_credit,aes(x=Credit.amount))+geom_histogram(binwidth = 500)
#
# Finding skewness of Credit.amount
#
skewness(german_credit$Credit.amount)
#
# As the skewness value is 1.946702 it is positively skewed.
#
# Finding the kurtosis of Credit.amount
#
kurtosis(german_credit$Credit.amount)
#
# Kurtosis value of 7.265163 means that the distribution is not normal.
#
# Lets find out the standard deviation of Credit.amount
#
sd(german_credit$Credit.amount)
#
# Lets check for outliers in the field Credit.amount using boxplot and boxplot.stats
#
boxplot(german_credit$Credit.amount)
#
boxplot.stats(german_credit$Credit.amount)
#
# There are lot of outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(german_credit$Credit.amount, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is abrupt jump between 93% and 94%. So we will have to replace the values greater than 7985.95 as 7985.95
#
# Outlier treatment for Credit.amount
#
german_credit$Credit.amount[which(german_credit$Credit.amount > 7985.95)] <- 7985.95
#
# Lets plot the box plot again for Credit.amount.
#
boxplot(german_credit$Credit.amount)
#
boxplot.stats(german_credit$Credit.amount)
#
# Its clear that the outliers have reduced.
#
# Univariate analysis of Age.in.Years
#
# Summary for Age.in.Years
#
summary(german_credit$Age.in.Years)
#
# From the summary it seems there are outliers in the data as the max value is way far from mean and 3rd quartile
#
# Histogram for Age.in.Years
#
ggplot(german_credit,aes(x=Age.in.Years))+geom_histogram(binwidth = 5)
#
# Finding skewness of Age.in.Years
#
skewness(german_credit$Age.in.Years)
#
# As the skewness value is 1.019208, it is slightly positively skewed.
#
# Finding the kurtosis of Age.in.Years
#
kurtosis(german_credit$Age.in.Years)
#
# Kurtosis value of 3.586811 means that the distribution is not normal.
#
# Lets find out the standard deviation of Age.in.Years
#
sd(german_credit$Age.in.Years)
#
# Lets check for outliers in the field Age.in.Years using boxplot and boxplot.stats
#
boxplot(german_credit$Age.in.Years)
#
boxplot.stats(german_credit$Age.in.Years)
#
# There are lot of outliers in the box plot or in the boxplot.stats result
#
# Lets check the percentile distribution as well using quantile
#
quantile(german_credit$Age.in.Years, seq(0,1,0.01))
#
# From the percentile distribution its clear that there is abrupt jump between 99% and 100%. So we will have to replace the values greater than 67.01 as 67.01
#
# Outlier treatment for Age.in.Years
#
german_credit$Age.in.Years[which(german_credit$Age.in.Years > 67.01)] <- 67.01
#
# Lets plot the box plot again for Age.in.Years
#
boxplot(german_credit$Age.in.Years)
#
boxplot.stats(german_credit$Age.in.Years)
#
# Its clear that the outliers have reduced.
# 
# Exploratory Data Analysis
#
# Univariate exploratory analysis and outlier treatment for the continous variables was done during data preparation stage.
#
# Starting univariate exploratory analysis for categorical variables.
#
# Univariate analysis of Status.of.existing.checking.account	  
#
# Lets find the count in each Status.of.existing.checking.account categories
#
table(factor(german_credit$Status.of.existing.checking.account))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Status.of.existing.checking.account))) + geom_bar()
#
# A13 has the least and A14 has the most loan taking customers 
#
# Univariate analysis of Credit.history	  
#
# Lets find the count in each Credit.history categories
#
table(factor(german_credit$Credit.history))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Credit.history))) + geom_bar()
#
# A32 has the majority and A30 has the least loan taking customers.
#
# Univariate analysis of Purpose	  
#
# Lets find the count in each Purpose categories
#
table(factor(german_credit$Purpose))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Purpose))) + geom_bar()
#
# A43 has the majority and A48 has the least loan taking customers.
#
# Univariate analysis of Savings.account.bonds	  
#
# Lets find the count in each Savings.account.bonds categories
#
table(factor(german_credit$Savings.account.bonds))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Savings.account.bonds))) + geom_bar()
#
# A61 has the majority and A64 has the least loan taking customers.
#
# Univariate analysis of Present.employment.since.	  
#
# Lets find the count in each Present.employment.since. categories
#
table(factor(german_credit$Present.employment.since.))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Present.employment.since.))) + geom_bar()
#
# A73 has the majority and A71 has the least loan taking customers.
#
# Univariate analysis of Installment.rate.in.percentage.of.disposable.income	  
#
# Lets find the count in each Installment.rate.in.percentage.of.disposable.income categories
#
table(factor(german_credit$Installment.rate.in.percentage.of.disposable.income))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Installment.rate.in.percentage.of.disposable.income))) + geom_bar()
#
# 4 has the majority and 1 has the least loan taking customers.
#
# Univariate analysis of Personal.status.and.sex	  
#
# Lets find the count in each Personal.status.and.sex categories
#
table(factor(german_credit$Personal.status.and.sex))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Personal.status.and.sex))) + geom_bar()
#
# A93 has the majority and A91 has the least loan taking customers.
#
# Univariate analysis of Other.debtors...guarantors	  
#
# Lets find the count in each Other.debtors...guarantors categories
#
table(factor(german_credit$Other.debtors...guarantors))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Other.debtors...guarantors))) + geom_bar()
#
# A101 has the majority and A102 has the least loan taking customers.
#
# Univariate analysis of Present.residence.since	  
#
# Lets find the count in each Present.residence.since categories
#
table(factor(german_credit$Present.residence.since))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Present.residence.since))) + geom_bar()
#
# 4 has the majority and 1 has the least loan taking customers.
#
# Univariate analysis of Property	  
#
# Lets find the count in each Property categories
#
table(factor(german_credit$Property))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Property))) + geom_bar()
#
# A123 has the majority and A124 has the least loan taking customers.
#
# Univariate analysis of Other.installment.plans	  
#
# Lets find the count in each Other.installment.plans categories
#
table(factor(german_credit$Other.installment.plans))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Other.installment.plans))) + geom_bar()
#
# A143 has the majority and A142 has the least loan taking customers.
#
# Univariate analysis of Housing.	  
#
# Lets find the count in each Housing. categories
#
table(factor(german_credit$Housing.))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Housing.))) + geom_bar()
#
# A152 has the majority and A153 has the least loan taking customers.
#
# Univariate analysis of Number.of.existing.credits.at.this.bank.	  
#
# Lets find the count in each Number.of.existing.credits.at.this.bank. categories
#
table(factor(german_credit$Number.of.existing.credits.at.this.bank.))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Number.of.existing.credits.at.this.bank.))) + geom_bar()
#
# 1 has the majority and 4 has the least loan taking customers.
#
# Univariate analysis of Job_status	  
#
# Lets find the count in each Job_status categories
#
table(factor(german_credit$Job_status))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Job_status))) + geom_bar()
#
# A173 has the majority and A171 has the least loan taking customers.
#
# Univariate analysis of Number.of.people.being.liable.to.provide.maintenance.for.	  
#
# Lets find the count in each Number.of.people.being.liable.to.provide.maintenance.for. categories
#
table(factor(german_credit$Number.of.people.being.liable.to.provide.maintenance.for.))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Number.of.people.being.liable.to.provide.maintenance.for.))) + geom_bar()
#
# 1 has the majority and 2 has the least loan taking customers.
#
# Univariate analysis of Telephone.	  
#
# Lets find the count in each Telephone. categories
#
table(factor(german_credit$Telephone.))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Telephone.))) + geom_bar()
#
# A191 has the majority and A192 has the least loan taking customers.
#
# Univariate analysis of foreign.worker	  
#
# Lets find the count in each foreign.worker categories
#
table(factor(german_credit$foreign.worker))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(foreign.worker))) + geom_bar()
#
# A201 has the majority and A202 has the least loan taking customers.
#
# Univariate analysis of Default_status	  
#
# Lets find the count in each Default_status categories
#
table(factor(german_credit$Default_status))
#
# Lets plot a bar chart for the same
#
ggplot(german_credit,aes(x=factor(Default_status))) + geom_bar()
#
# 0 has the majority and 1 has the least loan taking customers.
#
# Multivariate analysis
#
# Multivariate analysis of continous variables
#
# Finding correlations for Credit Amount and Age
#
cor(german_credit$Credit.amount, german_credit$Age.in.Years)
#
# The correlation value is 0.02556213 which is very less. 
#
# Finding correlations for Credit Amount and Duration
#
cor(german_credit$Credit.amount, german_credit$Duration.in.month)
#
# The correlation value is 0.6418831 which is very less. 
#
# Finding correlations for Age.in.Years and Duration
#
cor(german_credit$Age.in.Years, german_credit$Duration.in.month)
#
# The correlation value is -0.04150519 which is very less. 
#
# As our target variable is Default Status lets see how it is distributed in distribution of all the variables
#
# Distribution of Default_Status across continous variables
#
ggplot(german_credit,aes(x=Age.in.Years, fill = factor(Default_status)))+geom_histogram(binwidth = 5)
#
ggplot(german_credit,aes(x=Credit.amount, fill = factor(Default_status)))+geom_histogram(binwidth = 500)
#
ggplot(german_credit,aes(x=Duration.in.month, fill = factor(Default_status)))+geom_histogram(binwidth = 5)
#
# Distribution of Default_Status across categorical variables
#
ggplot(german_credit,aes(x=factor(Status.of.existing.checking.account), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Purpose), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Savings.account.bonds), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Present.employment.since.), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Installment.rate.in.percentage.of.disposable.income), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Personal.status.and.sex), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Other.debtors...guarantors), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Present.residence.since), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Property), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Other.installment.plans), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Housing.), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Number.of.existing.credits.at.this.bank.), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Job_status), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Number.of.people.being.liable.to.provide.maintenance.for.), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Telephone.), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(foreign.worker), fill = factor(Default_status))) + geom_bar()
#
ggplot(german_credit,aes(x=factor(Credit.history), fill = factor(Default_status))) + geom_bar()
#
# Initial Model with all variables
#
# First stage: Variables Formatting  
#
# Here we will convert the multi-valued discrete attributes to factors
#
german_credit$Status.of.existing.checking.account <- as.factor(german_credit$Status.of.existing.checking.account)
#
german_credit$Credit.history <- as.factor(german_credit$Credit.history)
#
german_credit$Purpose <- as.factor(german_credit$Purpose)
#
german_credit$Savings.account.bonds <- as.factor(german_credit$Savings.account.bonds)
#
german_credit$Present.employment.since. <- as.factor(german_credit$Present.employment.since.)
#
german_credit$Personal.status.and.sex <- as.factor(german_credit$Personal.status.and.sex)
#
german_credit$Other.debtors...guarantors <- as.factor(german_credit$Other.debtors...guarantors)
#
german_credit$Property <- as.factor(german_credit$Property)
#
german_credit$Other.installment.plans <- as.factor(german_credit$Other.installment.plans)
#
german_credit$Housing. <- as.factor(german_credit$Housing.)
#
german_credit$Job_status <- as.factor(german_credit$Job_status)
#
german_credit$Telephone. <- as.factor(german_credit$Telephone.)
#
german_credit$foreign.worker <- as.factor(german_credit$foreign.worker)
#
german_credit$Installment.rate.in.percentage.of.disposable.income <- as.factor(german_credit$Installment.rate.in.percentage.of.disposable.income)
#
german_credit$Present.residence.since <- as.factor(german_credit$Present.residence.since)
#
german_credit$Number.of.existing.credits.at.this.bank. <- as.factor(german_credit$Number.of.existing.credits.at.this.bank.)
#
german_credit$Number.of.people.being.liable.to.provide.maintenance.for. <- as.factor(german_credit$Number.of.people.being.liable.to.provide.maintenance.for.)
#
# Lets check the structure again of german_credit data frame
#
str(german_credit)
#
# Lets combine some insignificant categories in the categorical variables to reduce the variables
#
# Lets merge A410, A44,A45,A46,A48 categories in Purpose variables
#
# Checking the levels in purpose variable
#
levels(german_credit$Purpose)
#
# Changing A410, A44,A45,A46,A48 Purpose to A410_44_45_46_48
#
levels(german_credit$Purpose)[c(3,6,7,8,9)]<-"A410_44_45_46_48"
#
# Checking the levels again for Purpose variable
#
levels(german_credit$Purpose)
#
# Lets merge A62, A63, A64 categories in Savings.account.bonds variables
#
# Checking the levels in Savings.account.bonds variable
#
levels(german_credit$Savings.account.bonds)
#
# Changing A62, A63, A64 Savings.account.bonds to A62_63_64
#
levels(german_credit$Savings.account.bonds)[2:4]<-"A62_63_64"
#
# Checking the levels again for Purpose variable
#
levels(german_credit$Savings.account.bonds)
#
# Lets merge A91, A94 categories in Personal.status.and.sex variables
#
# Checking the levels in Personal.status.and.sex variable
#
levels(german_credit$Personal.status.and.sex)
#
# Changing A91, A94 Personal.status.and.sex to A91_94
#
levels(german_credit$Personal.status.and.sex)[c(1,4)]<-"A91_94"
#
# Checking the levels again for Purpose variable
#
levels(german_credit$Personal.status.and.sex)
#
# Lets merge A102, A103 categories in Other.debtors...guarantors variables
#
# Checking the levels in Other.debtors...guarantors variable
#
levels(german_credit$Other.debtors...guarantors)
#
# Changing A102, A103 Other.debtors...guarantors to A102_103
#
levels(german_credit$Other.debtors...guarantors)[c(2,3)]<-"A102_103"
#
# Checking the levels again for Other.debtors...guarantors variable
#
levels(german_credit$Other.debtors...guarantors)
#
# Lets merge A141,A142 categories in Other.installment.plans variables
#
# Checking the levels in Other.installment.plans variable
#
levels(german_credit$Other.installment.plans)
#
# Changing A141,A142 Other.installment.plans to A141_142
#
levels(german_credit$Other.installment.plans)[c(1,2)]<-"A141_142"
#
# Checking the levels again for Other.installment.plans variable
#
levels(german_credit$Other.installment.plans)
#
# Lets merge A151,A153 categories in Housing variables
#
# Checking the levels in Housing variable
#
levels(german_credit$Housing.)
#
# Changing A151,A153 Housing to A151_153
#
levels(german_credit$Housing.)[c(1,3)]<-"A151_153"
#
# Checking the levels again for Other.installment.plans variable
#
levels(german_credit$Housing.)
#
# Lets merge A171, A172 categories in Job_status variables
#
# Checking the levels in Job_status variable
#
levels(german_credit$Job_status)
#
# Changing A171, A172 Job_status to A171_172
#
levels(german_credit$Job_status)[c(1,2)]<-"A171_172"
#
# Checking the levels again for Job_status variable
#
levels(german_credit$Job_status)
#
# Checking the levels in Credit.history variable
#
levels(german_credit$Credit.history)
#
# Changing A30, A31 Credit.history to A30_31
#
levels(german_credit$Credit.history)[c(1,2)]<-"A30_31"
#
# Checking the levels again for Credit.history variable
#
levels(german_credit$Credit.history)
#
# Checking the levels in Number.of.existing.credits.at.this.bank. variable
#
levels(german_credit$Number.of.existing.credits.at.this.bank.)
#
# Changing 3, 4 Number.of.existing.credits.at.this.bank. to 3_4
#
levels(german_credit$Number.of.existing.credits.at.this.bank.)[c(3,4)]<-"3_4"
#
# Checking the levels again for Number.of.existing.credits.at.this.bank. variable
#
levels(german_credit$Number.of.existing.credits.at.this.bank.)
#
# Lets check the structure of german_credit data frame once again
#
str(german_credit)
#
# Standardizing the Credit amount variable
#
german_credit$Credit.amount <- scale(german_credit$Credit.amount)
#
# Standardizing the Age variable
#
german_credit$Age.in.Years <- scale(german_credit$Age.in.Years)
#
# Standardizing the Duration.in.month
#
german_credit$Duration.in.month <- scale(german_credit$Duration.in.month)
#
# Creating numeric variables for categorical variable Status.of.existing.checking.account
#
Status.of.existing.checking.account.numeric <- model.matrix(~Status.of.existing.checking.account -1 , data=german_credit)
#
# As there are 4 levels we need 3 variables to represent four levels. Lets remove the first column
#
Status.of.existing.checking.account.numeric <- Status.of.existing.checking.account.numeric[,-1]
#
# Creating numeric variables for categorical variable Credit.history
#
Credit.history.numeric <- model.matrix(~Credit.history -1 , data=german_credit)
#
# As there are 4 levels we need 3 variables to represent four levels. Lets remove the first column
#
Credit.history.numeric <- Credit.history.numeric[,-1]
#
# Creating numeric variables for categorical variable Purpose
#
Purpose.numeric <- model.matrix(~Purpose -1 , data=german_credit)
#
# As there are 6 levels we need 5 variables to represent six levels. Lets remove the first column
#
Purpose.numeric <- Purpose.numeric[,-1]
#
# Creating numeric variables for categorical variable Savings.account.bonds
#
Savings.account.bonds.numeric <- model.matrix(~Savings.account.bonds -1 , data=german_credit)
#
# As there are 3 levels we need 2 variables to represent three levels. Lets remove the first column
#
Savings.account.bonds.numeric <- Savings.account.bonds.numeric[,-1]
#
# Creating numeric variables for categorical variable Present.employment.since.
#
Present.employment.since.numeric <- model.matrix(~Present.employment.since. -1 , data=german_credit)
#
# As there are 5 levels we need 4 variables to represent five levels. Lets remove the first column
#
Present.employment.since.numeric <- Present.employment.since.numeric[,-1]
#
# Creating numeric variables for categorical variable Installment.rate.in.percentage.of.disposable.income
#
Installment.rate.in.percentage.of.disposable.income.numeric <- model.matrix(~Installment.rate.in.percentage.of.disposable.income -1 , data=german_credit)
#
# As there are 4 levels we need 3 variables to represent four levels. Lets remove the first column
#
Installment.rate.in.percentage.of.disposable.income.numeric <- Installment.rate.in.percentage.of.disposable.income.numeric[,-1]
#
# Creating numeric variables for categorical variable Personal.status.and.sex
#
Personal.status.and.sex.numeric <- model.matrix(~Personal.status.and.sex -1 , data=german_credit)
#
# As there are 3 levels we need 2 variables to represent three levels. Lets remove the first column
#
Personal.status.and.sex.numeric <- Personal.status.and.sex.numeric[,-1]
#
# Creating numeric variables for categorical variable Other.debtors...guarantors
#
Other.debtors...guarantors.numeric <- model.matrix(~Other.debtors...guarantors -1 , data=german_credit)
#
# As there are 2 levels we need 1 variables to represent two levels. Lets remove the first column
#
Other.debtors...guarantors.numeric.A102_103 <- Other.debtors...guarantors.numeric[,-1]
#
# Creating numeric variables for categorical variable Present.residence.since
#
Present.residence.since.numeric <- model.matrix(~Present.residence.since -1 , data=german_credit)
#
# As there are 4 levels we need 3 variables to represent four levels. Lets remove the first column
#
Present.residence.since.numeric <- Present.residence.since.numeric[,-1]
#
# Creating numeric variables for categorical variable Property
#
Property.numeric <- model.matrix(~Property -1 , data=german_credit)
#
# As there are 4 levels we need 3 variables to represent four levels. Lets remove the first column
#
Property.numeric <- Property.numeric[,-1]
#
# Creating numeric variables for categorical variable Other.installment.plans
#
Other.installment.plans.numeric <- model.matrix(~Other.installment.plans -1 , data=german_credit)
#
# As there are 2 levels we need 1 variable to represent two levels. Lets remove the first column
#
Other.installment.plans.A143 <- Other.installment.plans.numeric[,-1]
#
# Creating numeric variables for categorical variable Housing.
#
Housing.numeric <- model.matrix(~Housing. -1 , data=german_credit)
#
# As there are 2 levels we need 1 variable to represent two levels. Lets remove the first column
#
Housing.A152 <- Housing.numeric[,-1]
#
# Creating numeric variables for categorical variable Number.of.existing.credits.at.this.bank.
#
Number.of.existing.credits.at.this.bank.numeric <- model.matrix(~Number.of.existing.credits.at.this.bank. -1 , data=german_credit)
#
# As there are 3 levels we need 2 variable to represent three levels. Lets remove the first column
#
Number.of.existing.credits.at.this.bank.numeric <- Number.of.existing.credits.at.this.bank.numeric[,-1]
#
# Creating numeric variables for categorical variable Job_status
#
Job_status.numeric <- model.matrix(~Job_status -1 , data=german_credit)
#
# As there are 3 levels we need 2 variable to represent three levels. Lets remove the first column
#
Job_status.numeric <- Job_status.numeric[,-1]
#
# Creating numeric variables for categorical variable Number.of.people.being.liable.to.provide.maintenance.for.
#
Number.of.people.being.liable.to.provide.maintenance.for.numeric <- model.matrix(~Number.of.people.being.liable.to.provide.maintenance.for. -1 , data=german_credit)
#
# As there are 2 levels we need 1 variable to represent two levels. Lets remove the first column
#
Number.of.people.being.liable.to.provide.maintenance.for.2 <- Number.of.people.being.liable.to.provide.maintenance.for.numeric[,-1]
#
# Creating numeric variables for categorical variable Telephone.
#
Telephone.numeric <- model.matrix(~Telephone. -1 , data=german_credit)
#
# As there are 2 levels we need 1 variable to represent two levels. Lets remove the first column
#
Telephone.A192 <- Telephone.numeric[,-1]
#
# Creating numeric variables for categorical variable foreign.worker
#
foreign.worker.numeric <- model.matrix(~foreign.worker -1 , data=german_credit)
#
# As there are 2 levels we need 1 variable to represent two levels. Lets remove the first column
#
foreign.worker.A202 <- foreign.worker.numeric[,-1]
#
# Let us add the numeric columns to the data frame german_credit
#
german_credit <- cbind(german_credit, foreign.worker.A202, Housing.A152,Number.of.people.being.liable.to.provide.maintenance.for.2,Other.debtors...guarantors.numeric.A102_103,Other.installment.plans.A143,Telephone.A192)
#
german_credit <- cbind(german_credit, Status.of.existing.checking.account.numeric, Credit.history.numeric, Purpose.numeric, Savings.account.bonds.numeric, Present.employment.since.numeric, Installment.rate.in.percentage.of.disposable.income.numeric, Personal.status.and.sex.numeric, Present.residence.since.numeric, Property.numeric, Number.of.existing.credits.at.this.bank.numeric, Job_status.numeric)
#
# Remove all the categorical variables which are converted to numeric types
#
german_credit <- german_credit[,c(-1,-3,-4,-6,-7,-8,-9,-10,-11,-12,-14,-15,-16,-17,-18,-19,-20)]
#
# Lets split the data set into train and test
#
set.seed(100)
#
split_german_credit = sample.split(german_credit$Default_status, SplitRatio = 0.7)
#
table(split_german_credit)
#
train = german_credit[split_german_credit,]
#
test = german_credit[!(split_german_credit),]
#
# Model with all variables
#
initial_model = glm(Default_status ~ ., data = train, family = "binomial")
#
summary(initial_model)
#
# Stepwise selection of variables
#
best_model = step(initial_model,direction = "both")
#
# Remove multicollinearity through VIF check
#
summary(best_model)
#
vif(best_model)
#
# Here vif value of Credit.historyA32 is 3.131545. So let us remove this and build a new model
#
model_1 <- glm(Default_status ~ Duration.in.month + Age.in.Years + 
  foreign.worker.A202 + Housing.A152 + Other.installment.plans.A143 + 
  Status.of.existing.checking.accountA13 + Status.of.existing.checking.accountA14 + Credit.historyA33 + Credit.historyA34 + 
  PurposeA41 + PurposeA42 + PurposeA43 + PurposeA49 + Savings.account.bondsA62_63_64 + 
  Savings.account.bondsA65 + Present.employment.since.A74 + 
  Installment.rate.in.percentage.of.disposable.income4 + Personal.status.and.sexA93 + 
  Present.residence.since2, family = "binomial", data = train)
#
# Let us check the vif for this model
#
vif(model_1)
#
# Here all the variables have vif score less than 3, so there is no issue of multicollinearity.
#
# Now we will start removing variables based on significance level
#
summary(model_1)
#
# Let us remove Credit.historyA33 as it is least significant
#
model_2 <- glm(Default_status ~ Duration.in.month + Age.in.Years + 
                 foreign.worker.A202 + Housing.A152 + Other.installment.plans.A143 + 
                 Status.of.existing.checking.accountA13 + Status.of.existing.checking.accountA14 + Credit.historyA34 + PurposeA41 + PurposeA42 + 
                 PurposeA43 + PurposeA49 + Savings.account.bondsA62_63_64 + 
                 Savings.account.bondsA65 + Present.employment.since.A74 + 
                 Installment.rate.in.percentage.of.disposable.income4 + Personal.status.and.sexA93 + 
                 Present.residence.since2, family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_2)
#
# Let us remove Savings.account.bondsA62_63_64 as it is least significant
#
model_3 <- glm(Default_status ~ Duration.in.month + Age.in.Years + 
                 foreign.worker.A202 + Housing.A152 + Other.installment.plans.A143 + 
                 Status.of.existing.checking.accountA13 + Status.of.existing.checking.accountA14 + 
                 Credit.historyA34 + PurposeA41 + PurposeA42 + PurposeA43 + 
                 PurposeA49 + Savings.account.bondsA65 + 
                 Present.employment.since.A74 + Installment.rate.in.percentage.of.disposable.income4 + 
                 Personal.status.and.sexA93 + Present.residence.since2, family = "binomial", 
               data = train)
#
# Let's check the summary of the new model
#
summary(model_3)
#
# Let's remove Savings.account.bondsA65 as it is least significant
#
model_4 <- glm(Default_status ~ Duration.in.month + Age.in.Years + 
                 foreign.worker.A202 + Housing.A152 + Other.installment.plans.A143 + 
                 Status.of.existing.checking.accountA13 + Status.of.existing.checking.accountA14 + 
                 Credit.historyA34 + PurposeA41 + PurposeA42 + PurposeA43 + 
                 PurposeA49 + Present.employment.since.A74 + 
                 Installment.rate.in.percentage.of.disposable.income4 + Personal.status.and.sexA93 + 
                 Present.residence.since2, family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_4)
#
# Lets remove PurposeA49 as it is least significant
#
model_5 <- glm(Default_status ~ Duration.in.month + Age.in.Years + 
                 foreign.worker.A202 + Housing.A152 + Other.installment.plans.A143 + 
                 Status.of.existing.checking.accountA13 + Status.of.existing.checking.accountA14 + 
                 Credit.historyA34 + PurposeA41 + PurposeA42 + PurposeA43 + 
                 Present.employment.since.A74 + Installment.rate.in.percentage.of.disposable.income4 + 
                 Personal.status.and.sexA93 + Present.residence.since2, family = "binomial", 
               data = train)
#
# Let's check the summary of new model
#
summary(model_5)
#
# Lets remove foreign.worker.A202 as it is least significant
#
model_6 <- glm(formula = Default_status ~ Duration.in.month + Age.in.Years + Housing.A152 + Other.installment.plans.A143 + 
      Status.of.existing.checking.accountA13 + Status.of.existing.checking.accountA14 + 
      Credit.historyA34 + PurposeA41 + PurposeA42 + PurposeA43 + 
      Present.employment.since.A74 + Installment.rate.in.percentage.of.disposable.income4 + 
      Personal.status.and.sexA93 + Present.residence.since2, family = "binomial", 
    data = train)
#
# Let's check the summary of new model
#
summary(model_6)
#
# Lets remove Age.in.Years as it is least significant
#
model_7 <- glm(Default_status ~ Duration.in.month + 
                 Housing.A152 + Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                 Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                 PurposeA41 + PurposeA42 + PurposeA43 + Present.employment.since.A74 + 
                 Installment.rate.in.percentage.of.disposable.income4 + Personal.status.and.sexA93 + 
                 Present.residence.since2, family = "binomial", data = train)
#
# Let's check the summary of new model
#
summary(model_7)
#
# Lets remove PurposeA42 as it is least significant
#
model_8 <- glm(formula = Default_status ~ Duration.in.month + Housing.A152 + 
                 Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                 Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                 PurposeA41 + PurposeA43 + Present.employment.since.A74 + 
                 Installment.rate.in.percentage.of.disposable.income4 + Personal.status.and.sexA93 + 
                 Present.residence.since2, family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_8)
#
# Let's remove PurposeA43 as it is least significant
#
model_9 <- glm(formula = Default_status ~ Duration.in.month + Housing.A152 + 
                 Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                 Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                 PurposeA41 + Present.employment.since.A74 + 
                 Installment.rate.in.percentage.of.disposable.income4 + Personal.status.and.sexA93 + 
                 Present.residence.since2, family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_9)
#
# Lets remove Personal.status.and.sexA93 as it is least significant
#
model_10 <- glm(formula = Default_status ~ Duration.in.month + Housing.A152 + 
                  Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                  Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                  PurposeA41 + Present.employment.since.A74 + Installment.rate.in.percentage.of.disposable.income4
                   + Present.residence.since2, family = "binomial", 
                data = train)
#
# Let's check the summary of the new model
#
summary(model_10)
#
# Let's remove Present.residence.since2 as it is least significant
#
model_11 <- glm(formula = Default_status ~ Duration.in.month + Housing.A152 + 
                  Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                  Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                  PurposeA41 + Present.employment.since.A74 + Installment.rate.in.percentage.of.disposable.income4
                  , family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_11)
#
# Lets remove Present.employment.since.A74  as it is least significant
#
model_12 <- glm(formula = Default_status ~ Duration.in.month + Housing.A152 + 
      Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
      Status.of.existing.checking.accountA14 + Credit.historyA34 + 
      PurposeA41  + Installment.rate.in.percentage.of.disposable.income4, 
    family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_12)
#
# Let's remove PurposeA41 as it is least significant
#
model_13 <- glm(Default_status ~ Duration.in.month + Housing.A152 + 
                  Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                  Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                 Installment.rate.in.percentage.of.disposable.income4, 
                family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_13)
#
# Lets remove Housing.A152 as it is least significant
#
model_14 <- glm(formula = Default_status ~ Duration.in.month + 
                  Other.installment.plans.A143 + Status.of.existing.checking.accountA13 + 
                  Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                  Installment.rate.in.percentage.of.disposable.income4, family = "binomial", 
                data = train)
#
# Let's check the summary of the new model
#
summary(model_14)
#
# Lets remove Status.of.existing.checking.accountA13 as it is least significant
#
model_15 <- glm(formula = Default_status ~ Duration.in.month + Other.installment.plans.A143 + 
                    Status.of.existing.checking.accountA14 + 
                  Credit.historyA34 + Installment.rate.in.percentage.of.disposable.income4, 
                family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_15)
#
# Let's remove Other.installment.plans.A143 as it is least significant
#
model_16 <- glm(Default_status ~ Duration.in.month + 
                  Status.of.existing.checking.accountA14 + Credit.historyA34 + 
                  Installment.rate.in.percentage.of.disposable.income4, family = "binomial", 
                data = train)
#
# Let's check the summary of the new model
#
summary(model_16)
#
# Lets remove Installment.rate.in.percentage.of.disposable.income4 as it is least significant
#
model_17 <- glm(formula = Default_status ~ Duration.in.month + Status.of.existing.checking.accountA14 + 
                  Credit.historyA34, 
                family = "binomial", data = train)
#
# Let's check the summary of the new model
#
summary(model_17)
#
# None of the variables are insignificant in this model. So model_17 is the final model
#
final_model <- model_17
#
# c-statistic and KS -statistic
#
train$predicted_prob = predict(final_model,  type = "response")
#
rcorr.cens(train$predicted_prob,train$Default_status) # 1st argument is your vector of predicted probabilities, 2nd observed values of outcome variable
#
# Here the c parameter on train data is 7.629155e-01.
#
# Lets check the c parameter on test data
#
test$predicted_prob = predict(final_model, newdata = test,type = "response")
#
rcorr.cens(test$predicted_prob,test$Default_status)
#
# The c parameter is  7.191534e-01 on the test data which is quiet good.
#
# Let's calculate the K statistics
#
model_score <- prediction(train$predicted_prob,train$Default_status)
#
model_perf <- performance(model_score, "tpr", "fpr")
#
ks_table <- attr(model_perf, "y.values")[[1]] - (attr(model_perf, "x.values")[[1]])
#
ks = max(ks_table)
# 
# Therefore the KS statistic in this case is 0.4176871
#
which(ks_table == ks)
# 
# The output is 37
#
# So the decile is 
#
37/700
#
# The output is 0.05285714 which means the KS statistic lie in the first decile.
#
# Similarly, lets find out the KS statistic for the test data
#
model_score_test <- prediction(test$predicted_prob,test$Default_status)
#
model_perf_test <- performance(model_score_test, "tpr", "fpr")
#
ks_table_test <- attr(model_perf_test, "y.values")[[1]] - (attr(model_perf_test, "x.values")[[1]])
#
ks_test <- max(ks_table_test)
#
which(ks_table_test == ks_test)
#
21/300
#
# The output is 0.07 which means the KS statistic lie in the first decile.
#
# Which means our model performs well on the test data as well
#
# Selecting threshold value
#
plot(model_perf,col = "red", lab = c(10,10,10))
#
# Lets check the max probablity in the predicted probablities of train data
#
summary(train$predicted_prob)
#
# As of now the max prob is 0.6823575 and 75% of observations has prob less 0.4343
#
# Here we dont want defaulters at any cost so lets keep the threshold at 0.3 first and see how the model behaves with the train data
# We need a higher sensitivity
#
confusionMatrix(as.numeric(train$predicted_prob > 0.30),train$Default_status, positive = "1")
#
# This model with threshold as 0.30 gives a sensitivity of 0.8000, Specificity 0.6041 and accuracy 0.6629
#
# Lets repeat the same steps for test data
#
plot(model_perf_test,col = "red", lab = c(10,10,10))
#
confusionMatrix(as.numeric(test$predicted_prob > 0.30),test$Default_status, positive = "1")
#
# This model with threshold as 0.30 gives a sensitivity of 0.7444, Specificity 0.5952 and accuracy 0.64 on test data
